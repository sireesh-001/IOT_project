const char MAIN_page[] PROGMEM = R"=====(
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
</head>
<body>
  <center>
  <h3>Login Here</h3>
//  <form action="/Home.html" method="GET">
      <table>
        <tr>
          <td>Username:</td>
          <td><input type="text" name="user" placeholder="Enter name Here"></td>
        </tr>
        <tr>
          <td>Password:</td>
          <td><input type="password" name="user_pass" placeholder="Enter Password Here"></td>
        </tr>
        
        <tr>
           <td><a href="/Home.html"><input type="submit" name="submit" value="Login"></a></td>
           <td><p>Not yet a Member? <a href="/Home.html">Register</a></p></td>
        </tr>
      </table>
//  </form>
  
  </center>
</body>
</html>

)=====";


const char MAIN_page12[] PROGMEM = R"=====(
<!doctype html>
<html>
<head>
<title>IoT Motion detector</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <h1 style="text-align:center; color:blue;font-size: 2.5rem;">IoT Motion Detector</h1>
  <style>
  canvas{
    -moz-user-select: none;
    -webkit-user-select: none;
    -ms-user-select: none;
  }
  #data_table {
    font-family: New Times Roman;
    border-collapse: collapse;
    width: 100%;
    text-align: center;
    font-size: 0.8rem;
  }
  #data_table td, #data_table th {
    border: 3px solid #ddd;
    padding: 15px;
  }
  #data_table tr:nth-child(even){background-color: #faffff;}
  #data_table tr:hover {background-color: #faffff;}
  #data_table th {
    padding-top: 20px;
    padding-bottom: 20px;
    text-align: center;
    background-color: #190775;
    color: white;
  }
  </style>
</head>
<body>   
<div>
  <table id="data_table">
    <tr><th>Time</th><th>Activity</th></tr>
  </table>
</div>
<br>
<br>  
<script>

var Avalues = [];
var dateStamp = [];

setInterval(function() {
  getData();
}, 3000); 
function getData() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
  var date = new Date();
  var txt = this.responseText;
  var obj = JSON.parse(txt); 
      Avalues.push(obj.Activity);
      dateStamp.push(date);

    var table = document.getElementById("data_table");
    var row = table.insertRow(1); 
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    cell1.innerHTML = date;
    cell2.innerHTML = obj.Activity;
    }
  };
  xhttp.open("GET", "read_data", true); 
  xhttp.send();
}    
</script>
</body>
</html>

)=====";
